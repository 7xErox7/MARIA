# M.A.R.I.A.
Um projeto para fins educativos, que consiste em um sistema que registra entradas e saidas e responde de maneira inteligente.
